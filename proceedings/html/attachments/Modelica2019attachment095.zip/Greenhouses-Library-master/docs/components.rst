.. _components:

Components
==========


The **Components** package is the central part of the library. It is organized in three sub-packages:

.. toctree::
   :maxdepth: 2

   greenhouse
   hvac
   cropyield

